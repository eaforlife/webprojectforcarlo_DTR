<?php

require_once("./myCon.php");

if(isset($_POST['empID']) && isset($_POST['empName']) && isset($_POST['mode'])) {
	$empID = cleanTxt($_POST['empID']);
	$empName = cleanTxt($_POST['empName']);
	// Delete Employee
	if($_POST['mode'] == 'delete') {
		
		if(!empty($empID) && !empty($empName)) {
			$delEmp = "DELETE FROM emp_accounts WHERE acctID='$empID';";
			if($myConn->query($delEmp) === true) {
				echo "Deleted succcessfully. Remember this action is irreversible.<br>";
				echo "The recommended way of deleting employee is by selecting Archive.<br>";
				echo "Bringing you back to Records in a few seconds.<br>";
				header("Location: ./records.php");
			} else {
				echo "Something went wrong. Unable to delete employee.<br>";
				echo "Bringing you back to Records in a few seconds.<br>";
				header( "refresh:2;url=./records.php" );
			}
		}
		
	}
	
}

echo "<tr>";
echo "<th>ID</th>";
echo "<th>Employee Name</th>";
echo "<th>E-Mail</th>";
echo "<th>Status</th>";
echo "<th>Action</th>";
echo "</tr>";

if(isset($_GET['e']) && isset($_GET['p'])) {
	
	if($_GET['p'] == "records" && $_GET['e'] == "null") {
		$tableSQL = "SELECT * FROM emp_accounts;";
		$tblRslt = $myConn->query($tableSQL);
		
		if($tblRslt->num_rows >= 0) {
			while($row = $tblRslt->fetch_assoc()) {
				$empName = $row['lastName'] . ", " . $row['firstName'];
				$empID = $row['acctID'];
				echo "<tr>\n";
				
				echo "<td>$empID</td>\n";
				echo "<td>$empName</td>\n";
				echo "<td>" . $row['email'] . "</td>\n";
				if($row['status'] == 1)
					echo "<td class='txt-success'>Active</td>\n";
				else
					echo "<td class='txt-warning'>Archive</td>\n";
				echo "<td>";
				echo "<form method='post' id='tableAction-" . $row['acctID'] . "' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "'>\n";
				echo "<input type='hidden' value='$empName' id='empName$empID' name='empName'>\n";
				echo "<input type='hidden' value='$empID' id='empID$empID' name='empID'>\n";
				echo "<input type='hidden' value='delete' id='del' name='mode'>\n";
				echo "<button type='button' class='btn btn-info' name='frmEdit' onclick='modalEditEmp($empID)'>Edit&nbsp;</button>\n";
				echo "<button type='button' class='btn btn-danger' name='frmDel' onclick='modalDelEmp($empID)'>Delete&nbsp;</button>\n";
				echo "</form>\n";
				echo "</td>";
				echo "</tr>\n";
			}
		}
	}
	
	if($_GET['p'] == "records") {
		$searchTxt = $_GET['e'];
		$searchTxt = trim($searchTxt);
		$searchTxt = htmlspecialchars($searchTxt);
		
		
		$tableSQL = "SELECT * FROM emp_accounts WHERE CONCAT_WS(lastName, firstName) LIKE '%$searchTxt%' OR acctID LIKE '%$searchTxt%';";
		$tblRslt = $myConn->query($tableSQL);
		
		if($tblRslt->num_rows >= 0) {
			while($row = $tblRslt->fetch_assoc()) {
				$empName = $row['lastName'] . ", " . $row['firstName'];
				$empID = $row['acctID'];
				echo "<tr>\n";
				
				echo "<td>$empID</td>\n";
				echo "<td>$empName</td>\n";
				echo "<td>" . $row['email'] . "</td>\n";
				if($row['status'] == 1)
					echo "<td class='txt-success'>Active</td>\n";
				else
					echo "<td class='txt-warning'>Archive</td>\n";
				echo "<td>";
				echo "<form method='get' id='tableAction-" . $row['acctID'] . "'>\n";
				echo "<input type='hidden' value='$empName' id='empName$empID' name='empName'>\n";
				echo "<input type='hidden' value='$empID' id='empID$empID' name='empID'>\n";
				echo "<input type='hidden' value='delete' id='del' name='mode'>\n";
				echo "<input type='hidden' value='archive' id='del' name='mode'>\n";
				echo "<button type='button' class='btn btn-info' name='frmEdit' onclick='modalEditEmp($empID)'>Edit&nbsp;</button>\n";
				echo "<button type='button' class='btn btn-danger' name='frmDel' onclick='modalDelEmp($empID)'>Delete&nbsp;</button>\n";
				echo "</form>\n";
				echo "</td>";
				echo "</tr>\n";
			}
		}
	}
}
echo "</table>";

function cleanTxt($x) {
	$x = trim($x);
	$x = stripslashes($x);
	$x = htmlspecialchars($x);
	return $x;
}

?>