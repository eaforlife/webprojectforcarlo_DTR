<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="./style/style.css">
	<link rel="stylesheet" type="text/css" href="./style/style-1.css">
</head>
<body>
<?php
session_start();
$errMsg = "";

if(isset($_POST['uname']) && isset($_POST['pword'])) {

$username = $_POST['uname'];
$password = $_POST['pword'];

$username = trim($username);
$username = htmlspecialchars($username);
$password = trim($password);
$password = htmlspecialchars($password);

if(empty($username) && $username === "" && empty($password) && $password = "") {
	$errMsg = "One or more fields are empty. Please try again!";
} else {
	$errMsg = "";
	$password = md5($password); // encrypt password
	
	require("./myCon.php");
	$loginQuery = "SELECT * FROM emp_accounts WHERE userName LIKE '%$username%' AND passWord='$password' LIMIT 1;";
	$loginResult = $myConn->query($loginQuery);
	if($loginResult->num_rows > 0) {
		while($row = $loginResult->fetch_assoc()) {
			
			$_SESSION['login-id'] = $row['acctID'];
			$_SESSION['login-name'] = $row['firstName'];
			
			$cookieID = $row['acctID'];
			$cookieID .= $row['firstName'];
			$cookieID .= $password;
			$cookieID .= date("Y-m-dH:i:s");
			$empID = $row['acctID'];
			$cookieID = md5($cookieID);
			$cookieSQL = "INSERT INTO emp_login VALUES (NULL,'$empID','$cookieID','6');";
			$cookieRslt = $myConn->query($cookieSQL);
			
			$_SESSION['login-token'] = $cookieID;
		}
		header("Location: ./index.php");
		die();
	} else {
		$errMsg = "One or more fields are incorrect. Check if your inputs are correct";
	}
}
	
}

if(isset($_GET['log'])) {
	
	$login = $_GET['log'];
	$login = htmlspecialchars($login);
	$login = trim($login);
	
	// 1 = login,  0 = logout
	
	
	$message = "";
	$logID = "";
	// Check if user is currently logged in

	
	if($login == '1' && !isset($_SESSION['login-name'])) {
		// login codes ?>
		<div class="row">
			<div class="container">
				<div class="col-md-12">
					<h2>Login</h2>
					<form class="loginform" id="loginform" method="post">
						<?php if(!empty($errMsg)) { ?>
						<small><span class="txt-danger"><?php echo $errMsg ?></span></small><br><br>
						<?php	}  ?>
						<label for="uname">Username: </label>
						<input type="text" id="uname" name="uname" placeholder="Your Username" autocomplete="username"><br><br>
						<label for="pword">Password: </label>
						<input type="password" id="pword" name="pword" placeholder="Your Password(case sensitive)" autocomplete="current-password"><br><br>
						<input type="submit" class="btn-success" value="Login"><input type="reset" class="btn-light">
					</form>
					<br><br>
				</div>
			</div>
		</div>
		<?php } elseif($login == '0' && isset($_SESSION['login-name'])) { ?>
		<div class="row">
			<div class="container">
				<div class="col-md-2">&nbsp;</div>
				<div class="col-md-8">
					<h2>Logging Out. Please Wait.</h2>
				</div>
				<div class="col-md-2">&nbsp;</div>
			</div>
		</div>
		<?php
		unset($_SESSION['login-id']);
		unset($_SESSION['login-name']);
		header( "refresh:5;url=./index.php" );
		} else { ?>
		<div class="row">
			<div class="container">
				<div class="col-md-2">&nbsp;</div>
				<div class="col-md-8">
					<h2>We have encountered an unexpected error. Try again later or contact our site admin. Redirecting you to the homepage.</h2>
				</div>
				<div class="col-md-2">&nbsp;</div>
			</div>
		</div>
		<?php
		header( "refresh:5;url=./index.php" );
		}
		require_once("./require_footer.php");
		} else { ?>
	<div class="row">
		<div class="container">
			<div class="col-md-2">&nbsp;</div>
			<div class="col-md-8 col-flex">
				<h2>We have encountered an unexpected error. Try again later or contact our site admin.</h2><br>
				<p><small><a href="./index.php">Redirecting you to our homepage in 10 seconds.</a></small></p>
			</div>
			<div class="col-md-2">&nbsp;</div>
		</div>
	</div>
<?php } ?>
</body>
</html>