<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12">&nbsp;</div>
		</div>
		<div class="row">
			<div class="col-md-12"><hr class="shadow"></div>
		</div>
		<div class="row">
			<div class="col-md-1">&nbsp;</div>
			<div class="col-md-10 justify-center">
				<p><small>Date Time Record System &copy; 2020 | Powered by CSS Grid and HTML5</small></p>
			</div>
			<div class="col-md-1">&nbsp;</div>
		</div>
	</div>
</footer>