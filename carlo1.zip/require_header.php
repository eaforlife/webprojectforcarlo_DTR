<?php
	$logName = "";
	if(isset($_SESSION['login-id'])) {
		$logName = $_SESSION['login-name'];
		$logName = htmlspecialchars($logName);
	} else {
		$logName = "";
	}
?>
<header class="header shadow">
	<div class="container">
		<div class="row">
			<div class="header-title">
				<h4>Attendance Monitoring System</h4>
			</div>
			<div class="header-space">&nbsp;</div>
			<nav class="header-nav justify-center">
				<div class="nav">
					<a href='./index.php' active>Home</a>
					<a href='./records.php'>Records</a>
					<a href='./edit.php'>Tools</a>
					<?php if($logName === "") { ?>
					<a href='./login.php?log=1'>Login</a>
					<?php } else { ?>
					<a href='./login.php?log=0'>Logout <?php echo $logName; ?>?</a>
					<?php } ?>
				</div>
				<div class="nav-dropdown">
					<button class="btn btn-primary"><div class="hamburger"></div><div class="hamburger"></div><div class="hamburger"></div></button>
					<div class="nav-dropdown-content">
						<ul>
							<li><a href='./index.php' active>Home</a></li>
							<li><a href='./records.php'>Records</a></li>
							<li><a href='./edit.php'>Tools</a></li>
							<?php if($logName === "") { ?>
							<li><a href='./login.php?log=1'>Login</a></li>
							<?php } else { ?>
							<li><a href='./login.php?log=0'>Logout</a></li>
							<?php } ?>
						</ul>
					</div>
				</div>
			</nav>
		</div>
	</div>
</header>
