<!DOCTYPE html>
<!-- Use of CSS Grid: https://www.w3schools.com/css/css_grid.asp -->
<?php
session_start();
if(isset($_SESSION['login-name']) && isset($_SESSION['login-id'])) {
	$loginName = $_SESSION['login-name'];
	$loginID = $_SESSION['login-id'];
}
?>
<html>
<head>
<title>Date Time Record - Home</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0'> <!-- Call viewport for responsive html css: https://www.w3schools.com/html/html_responsive.asp -->
<link rel="stylesheet" type="text/css" href="./style/style.css">
<link rel="stylesheet" type="text/css" href="./style/style-1.css">
</head>
<body>

<!-- header -->
<?php 
	try {
		require("./require_header.php");
	} catch (ErrorException $err) {
		echo "<h1>Unable to load header module. Please try again later.</h1>";
		echo "<p>" . print_r($err) . "</p>";
		die();
	}
 ?>

<div class="container bottom-space">
<!-- content here -->
<div class="row">
	<div class="container">
		<div class="col-md-12 col-flex">
			<h2>Welcome!</h2>
		</div>
	</div>
</div>
<hr class="shadow">
<?php if(isset($_SESSION['login-name']) && isset($_SESSION['login-id'])) { ?>
<div class="row">
	<div class="container">
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-10">
		<h2>Welcome! <?php echo $loginName; ?></h2>
		</div>
		<div class="col-md-1">&nbsp;</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-5">
			<hr>
			<h2>Add Account</h2>
			<?php
			function cleanTxt($x) {
				$x = trim($x);
				$x = stripslashes($x);
				$x = htmlspecialchars($x);
				return $x;
			}
			function checkEmail($x) {
				if(!filter_var($x, FILTER_VALIDATE_EMAIL)) {
					return false;
				} else {
					return true;
				}
			}
			function checkLetters($x) {
				if(ctype_alpha($x)) {
					return true;
				} else {
					return false;
				}
			}
			
			if(isset($_POST['email']) && isset($_POST['firstName']) && isset($_POST['lastName']) && isset($_POST['password1']) && isset($_POST['password2'])) {
				$email = $_POST['email'];
				$fname = $_POST['firstName'];
				$lname = $_POST['lastName'];
				$pass1 = $_POST['password1'];
				$pass2 = $_POST['password2'];
				$pass = "";
				$admin = 0;
				
				$errArr = array();
				
				
				if(isset($_POST['admin'])) {
					$admin = 1;
				}
				
				$email = cleanTxt($email);
				$fname = cleanTxt($fname);
				$lname = cleanTxt($lname);
				$pass1 = cleanTxt($pass1);
				$pass2 = cleanTxt($pass2);
				
				if(empty($email) || checkEmail($email) === false) {
					$errArr[0] = "<small><span class='txt-danger'>Invalid or empty email address!</span></small>";
				}
				if(empty($fname) || checkLetters($fname) === false) {
					$errArr[1] = "<small><span class='txt-danger'>Invalid or empty first name!</span></small>";
				}
				if(empty($lname) || checkLetters($lname) === false) {
					$errArr[2] = "<small><span class='txt-danger'>Invalid or empty last name!</span></small>";
				}
				if(empty($pass1)) {
					$errArr[3] = "<small><span class='txt-danger'>Invalid or empty password field!</span></small>";
				} else {
					if(strlen($pass1) < 8) {
						$errArr[5] = "<small><span class='txt-danger'>Password must be more than or equal to 8 characters!</span></small>";
					}
				}
				if(empty($pass2)) {
					$errArr[4] = "<small><span class='txt-danger'>Invalid or empty password field!</span></small>";
				} else {
					if(strlen($pass2) < 8) {
						$errArr[6] = "<small><span class='txt-danger'>Password must be more than or equal to 8 characters!</span></small>";
					} else {
						if($pass1 != $pass2) {
							$errArr[7] = "<small><span class='txt-danger'>Password must match!</span></small>";
						}
					}
				}
				
				if(empty($errArr)) {
					require("./myCon.php");
					
					$newID = 404;
					$createID = "SELECT * FROM emp_accounts ORDER BY acctID DESC LIMIT 1";
					$idSQL = $myConn->query($createID);
					if($idSQL->num_rows > 0) {
						while($row = $idSQL->fetch_assoc()) {
							$newID = $row['acctID'];
							$newID = $newID + 1;
						}
					}
					
					$checkEmail = "SELECT * FROM emp_accounts WHERE email='$email';";
					$checkSQL = $myConn->query($checkEmail);
					if($checkSQL->num_rows > 0) {
						$errArr[0] = "<small><span class='txt-danger'>E-Mail already exists in our system!</span></small>";
					}
					
					if(empty($errArr)) {
						$pass = md5($pass1);
						$username = $fname[0] . $lname[0] . $newID;
						
						$createEmp = "INSERT INTO emp_accounts VALUES ('$newID', '$fname', '$lname', '$username', '$pass', '$email', '1', '$admin');";
						if($myConn->query($createEmp) === TRUE) {
							echo "<div id='success-msg'>";
							echo "<h2 class='txt-success'>Successfully added employee!</h2>";
							echo "<p class='txt-success'><small>Your employee ID: $newID</small></p>";
							echo "<p class='txt-success'><small>Your username: $username</small></p>";
							echo "<p class='txt-success'><small>Your password: $pass</small></p>";
							echo "</div>";
							header( "refresh:2;url=./index.php" );
						} else {
							echo "<p class='txt-danger'><small>Something went wrong while adding the account</small></p>";
						}
					}
				}
			}
			?>
			<form method="post" id="frmAdd" class="frmAdd">
				<label for="frmEmail">E-Mail: </label>
				<input type="text" name="email" id="frmEmail" placeholder="Valid E-Mail Address" autocomplete="username">&nbsp;
				<?php if(!empty($errArr[0])){ echo $errArr[0]; } ?><br>
				<label for="frmFirstName">First Name: </label>
				<input type="text" name="firstName" id="frmFirstName" placeholder="First Name">&nbsp;
				<?php if(!empty($errArr[1])){ echo $errArr[1]; } ?><br>
				<label for="frmLastName">Last Name: </label>
				<input type="text" name="lastName" id="frmLastName" placeholder="Last Name">
				<?php if(!empty($errArr[2])){ echo $errArr[2]; } ?><br>
				<label for="frmPassword1">Password: </label>
				<input type="password" name="password1" id="frmPassword1" autocomplete="new-password" required>&nbsp;
				<?php if(!empty($errArr[3])){ echo $errArr[3]; } ?><br>
				<label for="frmPassword2">Confirm Password: </label>
				<input type="password" name="password2" id="frmPassword2" autocomplete="new-password" required>&nbsp;
				<?php if(!empty($errArr[4])){ echo $errArr[4]; } ?><br>
				<label for="isadmin">Is Admin?</label>
				<input type="checkbox" value="yes" id="frmAdmin" name="admin"><br><br>
				<input type="submit" class="btn-success" value="Create">
			</form>
			<div id="addEmployee"></div>
		</div>
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-4">
			<h2>HI</h2>
		</div>
		<div class="col-md-1">&nbsp;</div>
	</div>
</div>
<?php } else { ?>
<div class="row">
	<div class="container">
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-10">
		<h2><a href="./login.php?log=1">You are not logged in! Sending you to login page</a></h2>
		</div>
		<div class="col-md-1">&nbsp;</div>
	</div>
</div>
<?php 
header( "refresh:5;url=./login.php?log=1" );
} ?>

<hr>
<?php 
	include("./require_footer.php");
 ?>

<script>
var success = document.getElementById("success-msg");

if (document.contains(success)) {
	setTimeout(success.style.block = "none", 3000);
}
</script>

</body>
</html>